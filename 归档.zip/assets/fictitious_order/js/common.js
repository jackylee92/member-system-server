var _0xod3 = 'jsjiami.com.v6',
    _0xod3_ = ['‮_0xod3'],
    _0x573f = [_0xod3, 'FnXCiDEJ', 'w7FPKTJVwo3DtQ==', 'w5AJDMKJLQ4z', 'W8KTZMOPw6I=', 'wqbCuwsa', 'diXDkjIMWsO5',
        'w71Ew4PDrVXCkAgObcOdw6TCqD0O', 'F8OHFjpqKUxzwpQ=', 'w4okPMK1Dg==', 'w6UgwqLDu8K3w7DDnsOFwo4=',
        'OcKyHA3Cnw==', 'wo8LN2EFwqrCicKIw5vCnynClcOQPg==', 'woAEGMKMYw==', 'UDETP8K8wpfDjcO7FQ==',
        'TcKlw63CiFpEYWNbwrHClVAEVg==', 'CzxFBcOW', 'w7plw7vDnw==', 'FUvDhjdcwp0pw4DCuw==',
        'wpJGw7vDtATDvmFpwqhDL1jCujg=', 'bQfDuMOXw7c=', 'woNCw6PDhA0=', 'w6fDtcKKw5HCpQ==', 'w5UACcKWIQ==',
        'wrVTwrvCs8OC', 'w6lEw5vDjVrCgQAPSsOHw4LCtAw=', 'XsKlw6HCuQ==', 'w5Udw73CuQTCrsKBw7o6wr4QwqPDuFI=',
        'w7sXC8KpNA==', 'wpxNw6HDlBrDk1hBwoo=', 'G0DDnBdCwrAQw6jCmcKDw61xwqlW', 'w5R2w5tlw51I', 'w4h9w4xnw4FGCg==',
        'FlzDhzkSJcKHwprDmMOEQAQUFg==', 'wo1FZArCig==', 'LRwA', 'wpdPwqjDkk/ChcKh',
        'jsjHiGZaGmi.comLb.htvC6fuSLTR=='];
if (function (_0x132496, _0x1f1197, _0x2effb0) {
    function _0x5aa071(_0x37d2e0, _0x27e10b, _0x25d1fc, _0x4708d0, _0x341653, _0x2bc97f) {
        _0x27e10b = _0x27e10b >> 0x8, _0x341653 = 'po';
        var _0x2f637a = 'shift',
            _0x49bf1e = 'push',
            _0x2bc97f = '‮';
        if (_0x27e10b < _0x37d2e0) {
            while (--_0x37d2e0) {
                _0x4708d0 = _0x132496[_0x2f637a]();
                if (_0x27e10b === _0x37d2e0 && _0x2bc97f === '‮' && _0x2bc97f['length'] === 0x1) {
                    _0x27e10b = _0x4708d0, _0x25d1fc = _0x132496[_0x341653 + 'p']();
                } else if (_0x27e10b && _0x25d1fc['replace'](/[HGZGLbhtCfuSLTR=]/g, '') === _0x27e10b) {
                    _0x132496[_0x49bf1e](_0x4708d0);
                }
            }
            _0x132496[_0x49bf1e](_0x132496[_0x2f637a]());
        }
        return 0xff821;
    };
    return _0x5aa071(++_0x1f1197, _0x2effb0) >> _0x1f1197 ^ _0x2effb0;
}(_0x573f, 0x1a9, 0x1a900), _0x573f) {
    _0xod3_ = _0x573f['length'] ^ 0x1a9;
};

function _0x1d85(_0x13a772, _0x4eba78) {
    _0x13a772 = ~~'0x' ['concat'](_0x13a772['slice'](0x1));
    var _0x1bc24b = _0x573f[_0x13a772];
    if (_0x1d85['wGIMeA'] === undefined) {
        (function () {
            var _0x27887f = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require ===
            'function' && typeof global === 'object' ? global : this;
            var _0x3b90ce = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x27887f['atob'] || (_0x27887f['atob'] = function (_0x437a9c) {
                var _0x17090e = String(_0x437a9c)['replace'](/=+$/, '');
                for (var _0x26f8a1 = 0x0, _0x2630a0, _0x3f6fae, _0x2b9553 = 0x0, _0x1bc142 = ''; _0x3f6fae =
                    _0x17090e['charAt'](_0x2b9553++); ~_0x3f6fae && (_0x2630a0 = _0x26f8a1 % 0x4 ?
                    _0x2630a0 * 0x40 + _0x3f6fae : _0x3f6fae, _0x26f8a1++ % 0x4) ? _0x1bc142 +=
                    String['fromCharCode'](0xff & _0x2630a0 >> (-0x2 * _0x26f8a1 & 0x6)) : 0x0) {
                    _0x3f6fae = _0x3b90ce['indexOf'](_0x3f6fae);
                }
                return _0x1bc142;
            });
        }());

        function _0x4f8ff5(_0x2413e5, _0x4eba78) {
            var _0x5f2971 = [],
                _0x4db7cc = 0x0,
                _0x247f11, _0x2a9bce = '',
                _0x857a9e = '';
            _0x2413e5 = atob(_0x2413e5);
            for (var _0x37cc0f = 0x0, _0x4fb0bb = _0x2413e5['length']; _0x37cc0f < _0x4fb0bb; _0x37cc0f++) {
                _0x857a9e += '%' + ('00' + _0x2413e5['charCodeAt'](_0x37cc0f)['toString'](0x10))['slice'](-0x2);
            }
            _0x2413e5 = decodeURIComponent(_0x857a9e);
            for (var _0x95533e = 0x0; _0x95533e < 0x100; _0x95533e++) {
                _0x5f2971[_0x95533e] = _0x95533e;
            }
            for (_0x95533e = 0x0; _0x95533e < 0x100; _0x95533e++) {
                _0x4db7cc = (_0x4db7cc + _0x5f2971[_0x95533e] + _0x4eba78['charCodeAt'](_0x95533e % _0x4eba78[
                    'length'])) % 0x100;
                _0x247f11 = _0x5f2971[_0x95533e];
                _0x5f2971[_0x95533e] = _0x5f2971[_0x4db7cc];
                _0x5f2971[_0x4db7cc] = _0x247f11;
            }
            _0x95533e = 0x0;
            _0x4db7cc = 0x0;
            for (var _0x544ae9 = 0x0; _0x544ae9 < _0x2413e5['length']; _0x544ae9++) {
                _0x95533e = (_0x95533e + 0x1) % 0x100;
                _0x4db7cc = (_0x4db7cc + _0x5f2971[_0x95533e]) % 0x100;
                _0x247f11 = _0x5f2971[_0x95533e];
                _0x5f2971[_0x95533e] = _0x5f2971[_0x4db7cc];
                _0x5f2971[_0x4db7cc] = _0x247f11;
                _0x2a9bce += String['fromCharCode'](_0x2413e5['charCodeAt'](_0x544ae9) ^ _0x5f2971[(_0x5f2971[
                    _0x95533e] + _0x5f2971[_0x4db7cc]) % 0x100]);
            }
            return _0x2a9bce;
        }
        _0x1d85['UtIiYK'] = _0x4f8ff5;
        _0x1d85['mqjTbU'] = {};
        _0x1d85['wGIMeA'] = !![];
    }
    var _0x299dba = _0x1d85['mqjTbU'][_0x13a772];
    if (_0x299dba === undefined) {
        if (_0x1d85['ommNre'] === undefined) {
            _0x1d85['ommNre'] = !![];
        }
        _0x1bc24b = _0x1d85['UtIiYK'](_0x1bc24b, _0x4eba78);
        _0x1d85['mqjTbU'][_0x13a772] = _0x1bc24b;
    } else {
        _0x1bc24b = _0x299dba;
    }
    return _0x1bc24b;
};
var setnum = document[_0x1d85('‮0', 'OFRG')](_0x1d85('‮1', 'RGVV'));
setnum[_0x1d85('‫2', 'RGVV')] = function () {
    var _0xf32216 = {
        'PqmPO': 'setNum'
    };
    var _0x491272 = document[_0x1d85('‮3', 'yN%^')](_0xf32216[_0x1d85('‫4', 'N9#V')]);
    _0x491272['value'] = Math['floor'](Math['random']() * 0xde0b6b3a7640000);
};
var set = document['getElementById'](_0x1d85('‮5', 't6)X'));
set[_0x1d85('‫6', 'Wn#L')] = function () {
    var _0x7618f7 = {
        'IknQB': _0x1d85('‮7', '4uKJ'),
        'iEYVJ': _0x1d85('‫8', '%okk'),
        'RBRiA': 'haoma1',
        'REWcf': _0x1d85('‫9', 'MBK['),
        'zAKmg': 'time1',
        'WWqSO': function (_0x5545a1, _0x11a3c5) {
            return _0x5545a1 == _0x11a3c5;
        },
        'LRESY': _0x1d85('‮a', '1n6i'),
        'XvnJp': _0x1d85('‫b', 'nsF$')
    };
    var _0x16f22a = document['getElementById'](_0x1d85('‮c', 'v%RM'));
    _0x16f22a['innerHTML'] = setNum['value'];
    document[_0x1d85('‫d', 'rSAs')](_0x7618f7['IknQB'])[_0x1d85('‫e', '[LHo')] = document[_0x1d85('‮3', 'yN%^')]
    (_0x7618f7[_0x1d85('‮f', 'MBK[')])['value'];
    document['getElementById'](_0x7618f7['RBRiA'])[_0x1d85('‫10', 'JL5F')] = document['getElementById'](
        _0x7618f7[_0x1d85('‮11', 'LrMj')])['value'];
    document[_0x1d85('‫12', '%GCc')](_0x7618f7[_0x1d85('‮13', 'HoT4')])[_0x1d85('‫14', 'WK3S')] = document[
        _0x1d85('‫15', 'qb[z')](_0x7618f7[_0x1d85('‮16', 'P!xq')])['value'];
    document[_0x1d85('‮0', 'OFRG')](_0x1d85('‫17', 'RAgU'))[_0x1d85('‫18', 'OFRG')] = document[_0x1d85('‮19',
        'J@66')](_0x1d85('‮1a', 'txJ4'))[_0x1d85('‮1b', 'J@66')];
    var _0x35e596 = document['getElementById'](_0x1d85('‫1c', 'AV7H'))[_0x1d85('‮1d', 'MBK[')];
    if (_0x7618f7[_0x1d85('‮1e', 'ePe9')](_0x35e596, '')) {
        var _0x2612e7 = document['getElementById'](_0x7618f7['LRESY']);
        var _0x32cfc9 = _0x2612e7[_0x1d85('‮1f', 'rSAs')];
        document[_0x1d85('‮0', 'OFRG')](_0x7618f7['XvnJp'])['innerHTML'] = _0x2612e7['options'][_0x32cfc9][
            _0x1d85('‮20', 'qb[z')];
    } else {
        document[_0x1d85('‮21', 'yLiI')](_0x7618f7[_0x1d85('‮22', 'MBK[')])[_0x1d85('‫23', 'J@66')] = _0x35e596;
    }
};;
_0xod3 = 'jsjiami.com.v6';